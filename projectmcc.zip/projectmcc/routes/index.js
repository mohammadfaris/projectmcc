var express = require('express');
var router = express.Router();
var connection = require('../config/db');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/akun',function(req, res, next){
	var ambil = "SELECT * FROM akun";
	var para = [];

	connection.query(ambil, para, function(err, result){
		if(err){
			console.log(err);
			throw err;
		}
		console.log(result);
		res.render('akun',{data:result});
	});
});
router.post ('/doInsert', function(req, res, next){
var akunname = req.body.akunname;
var akunpass = req.body.akunpass;

var ambil = "INSERT INTO akun(akunname,akunpass) VALUES (?,?)";
var para =[akunname, akunpass];

connection.query(ambil, para, function(err,result){

	if(err){
		console.log(err);
		throw err ;
}
console.log(result);
res.redirect('/akun',{data:result});
});
});

router.get('/',function(req, res, next){
	var akunID = req.query.akunID;
	var ambil = "DELETE FROM akun WHERE akunID = ?";
	var para = [akunID];

	connection.query(ambil, para, function(err, result){
		if(err)
		{
			console.log(err);
			throw err;
		}
		res.render('',{data:result});
	});

});

module.exports = router;
